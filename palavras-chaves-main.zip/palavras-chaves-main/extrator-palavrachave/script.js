const botaoMostraPalavras = document.queryselector('#botao-palavrachave');

botaoMostraPalavras.addEventListener('click', mostraPalavrasChave);

function mostraPalavrasChave(){
    alert('Fui clicado!')
}